import { EventEmitter, Injectable, Output } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class MyServicesService {
  UrlRegex = 'http://localhost:8080'; // angular server orgin
  urlLocal = 'http://localhost:8080';

  @Output() logsignal = new EventEmitter<boolean>();
  constructor(private httpReq: HttpClient) { }

  postReq(url: any, data: any)
  {
    const HttpOpt = new HttpHeaders({
      'Content-Type': 'application/json'
    });

    url = url.replace(this.urlLocal, this.UrlRegex);
    console.log(data);
    return this.httpReq.post(url, data, { headers: HttpOpt });
  }

  getReq(url: any) {
    const HttpOpt = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    url = url.replace(this.urlLocal, this.UrlRegex);
    console.log(url);
    return this.httpReq.get(url, {headers: HttpOpt});
  }

  deleteReq(url: any)
  {
    const HttpOpt = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    url = url.replace(this.urlLocal, this.UrlRegex);
    return this.httpReq.delete(url, { headers: HttpOpt });
  }

  putReq(url: any, data: any)
  {
    const HttpOpt = new HttpHeaders({
      'Content-Type': 'application/json'
    });

    url = url.replace(this.urlLocal, this.UrlRegex);
    console.log(data);
    return this.httpReq.put(url, data, { headers: HttpOpt });
   }
}
