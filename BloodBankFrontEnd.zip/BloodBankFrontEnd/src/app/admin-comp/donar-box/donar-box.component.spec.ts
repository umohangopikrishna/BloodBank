import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DonarBoxComponent } from './donar-box.component';

describe('DonarBoxComponent', () => {
  let component: DonarBoxComponent;
  let fixture: ComponentFixture<DonarBoxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DonarBoxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DonarBoxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
