import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MyServicesService } from '../HttpServices/my-services.service';

@Component({
  selector: 'app-admin-comp',
  templateUrl: './admin-comp.component.html',
  styleUrls: ['./admin-comp.component.css']
})
export class AdminCompComponent implements OnInit {

  optionSelected: number;
  actionMode: number;  // 0 for delete 1 for update
  donerList: any = [];
  donersearchList: any = [];
  operationName: string;
  seleteDonerToUpdate: any;

  searchData: string;
  delteloader: number;
  loaderall: boolean;
  constructor(private httpReq: MyServicesService , private router: Router)
  {
    this.loaderall = false;
    this.delteloader = -1;
    this.optionSelected = 1;
    if (sessionStorage.getItem('checkSequencePath') !== 'true')
    {
      this.router.navigate([''], { replaceUrl: true });
    }
  }

  ngOnInit(): void {
    this.actionMode = -1;
    this.getAllDonors();
  }

  refreash() {
    this.getAllDonors();
  }
  getAllDonors(): void
  {
    this.loaderall = true;
    this.httpReq.getReq('http://localhost:8080/getAllDoners/').subscribe(
      response => {
        this.donerList = response;
        console.log(response);
        this.searchByFields('');
        this.loaderall = false;
       });
  }

  deleteDonar(id: any, donerData: any)
  {
    this.delteloader = id;
    this.httpReq.deleteReq('http://localhost:8080/deleteDonar/' + id).subscribe(
      response => {
        console.log(response);
        const index = this.donerList.indexOf(donerData, 0);
        this.delteloader = -1;
        if (index > -1) {
          this.donerList.splice(index, 1);
        }
        this.searchByFields('');
        console.log(this.donerList);
      },
      err => {
        this.delteloader = -1;
       });
  }
  updateDonar(donarData: any)
  {
    this.seleteDonerToUpdate = donarData;
    this.actionMode = (this.actionMode !== 1) ? 1 : -1;
  }


  searchByFields(data: string)
  {
    console.log(data);
    this.donersearchList = [];
    for (const donarIndex in this.donerList)
    {
      if (String(this.donerList[donarIndex].donarName).includes(data)) {
        this.donersearchList.push(this.donerList[donarIndex]);
      }
      else if (String(this.donerList[donarIndex].age).includes(data)) {
        this.donersearchList.push(this.donerList[donarIndex]);
      }
      else if (String(this.donerList[donarIndex].weight).includes(data))
      {
        this.donersearchList.push(this.donerList[donarIndex]);
       }
      else if (String(this.donerList[donarIndex].phoneNumber).includes(data))
      {
        this.donersearchList.push(this.donerList[donarIndex]);
       }
      else if (String(this.donerList[donarIndex].pressure).includes(data))
      {
        this.donersearchList.push(this.donerList[donarIndex]);
       }
      else if (String(this.donerList[donarIndex].pHLevel).includes(data))
      {
        this.donersearchList.push(this.donerList[donarIndex]);
       }
      else if (String(this.donerList[donarIndex].bloodgroup).includes(data))
      {
        this.donersearchList.push(this.donerList[donarIndex]);
       }
      else if (data === null || data === '')
      {
        this.donersearchList.push(this.donerList[donarIndex]);
       }
    }
    console.log(this.donersearchList);
  }


}
