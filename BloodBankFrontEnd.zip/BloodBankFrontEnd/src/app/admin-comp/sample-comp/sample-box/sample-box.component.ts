import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-sample-box',
  templateUrl: './sample-box.component.html',
  styleUrls: ['./sample-box.component.css']
})
export class SampleBoxComponent implements OnInit {

  @Input() sampleData: any;
  Id: number;
  address: string;
  bloodgroup: string;
  location: string;
  packs: number;
  phlevel: number;
  phoneNumber: string;
  pressure: number;

  viewMoreInfo: boolean;
  constructor()
  {
    this.viewMoreInfo = false;
   }

  ngOnInit(): void {
    this.Id = this.sampleData.id;
    this.address = this.sampleData.address;
    this.bloodgroup = this.sampleData.bloodgroup;
    this.location = this.sampleData.location;
    this.packs = this.sampleData.packs;
    this.phlevel = this.sampleData.phlevel;
    this.phoneNumber = this.sampleData.phoneNumber;
    this.pressure = this.sampleData.pressure;
  }

}
