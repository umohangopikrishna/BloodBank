import { Component, OnInit } from '@angular/core';
import { MyServicesService } from 'src/app/HttpServices/my-services.service';

@Component({
  selector: 'app-sample-comp',
  templateUrl: './sample-comp.component.html',
  styleUrls: ['./sample-comp.component.css']
})
export class SampleCompComponent implements OnInit {

  sampleDataList: any = [];
  samplesearchList: any = [];
  actionMode: number;
  sampleData: any;
  searchData: string;
  delteloader: number;
  constructor(private httpReq: MyServicesService ) {
    this.actionMode = -1;
    this.delteloader = -1;
   }

  ngOnInit(): void {
    this.searchData = '';
    this.getAllSamples();
  }
  refreshSamples()
  {
    this.getAllSamples();
   }
  getAllSamples() {
    this.httpReq.getReq('http://localhost:8080/getAllSamples/').subscribe(
      response => {
        this.sampleDataList = response;
        console.log(this.sampleDataList);
        this.searchByFields();
      });
  }
  deleteSample(id: number , sampleObj: any)
  {
    this.delteloader = id;
    this.httpReq.deleteReq('http://localhost:8080/deleteSample/' + id).subscribe(
      response => {
        console.log(response);
        const index = this.sampleDataList.indexOf(sampleObj, 0);
        if (index > -1) {
          this.sampleDataList.splice(index, 1);
        }
        this.delteloader = -1;
        this.searchByFields();
      },
      err => {
        this.delteloader = -1;
            });
   }
  updateSample(sampleObj: any)
  {
    this.actionMode = this.actionMode !== 1 ? 1 : -1;
    this.sampleData = sampleObj;
  }

  searchByFields() {
    const data = this.searchData;

    this.samplesearchList = [];
    for (const sampleIndex in this.sampleDataList) {

      if (String(this.sampleDataList[sampleIndex].bloodgroup).includes(data)) {
        this.samplesearchList.push(this.sampleDataList[sampleIndex]);
        console.log('B+');

      }
      else if (String(this.sampleDataList[sampleIndex].pressure).includes(data)) {
        this.samplesearchList.push(this.sampleDataList[sampleIndex]);
      }
      else if (String(this.sampleDataList[sampleIndex].phoneNumber).includes(data)) {
        this.samplesearchList.push(this.sampleDataList[sampleIndex]);
      }
      else if (String(this.sampleDataList[sampleIndex].phlevel).includes(data)) {
        this.samplesearchList.push(this.sampleDataList[sampleIndex]);
      }
      else if (String(this.sampleDataList[sampleIndex].packs).includes(data)) {
        this.samplesearchList.push(this.sampleDataList[sampleIndex]);
      }
      else if (String(this.sampleDataList[sampleIndex].address).includes(data)) {
        this.samplesearchList.push(this.sampleDataList[sampleIndex]);
      }
      else if (String(this.sampleDataList[sampleIndex].id).includes(data)) {
        this.samplesearchList.push(this.sampleDataList[sampleIndex]);
      } else if (data === '')
      {
        this.samplesearchList.push(this.sampleDataList[sampleIndex]);
        console.log('Empty');
       }

    }
  }
}
