import { Component, OnInit } from '@angular/core';
import { MyServicesService } from 'src/app/HttpServices/my-services.service';

@Component({
  selector: 'app-add-sample',
  templateUrl: './add-sample.component.html',
  styleUrls: ['./add-sample.component.css']
})
export class AddSampleComponent implements OnInit {

  location: string;
  packs: number;
  packetdate: string;
  phoneNumber: string;
  address: string;
  phlevel: number;
  pressure: number;
  bloodgroup: string;
  loader: boolean;

  formData: any = {
    location: '',
    packs: 0,
    packetdate: '',
    phoneNumber: '',
    address: '',
    phlevel: 0,
    pressure: 0,
    bloodgroup: '',

  };


  constructor(private httpReq: MyServicesService) {
    this.loader = false;
    if (navigator.geolocation) {

      navigator.geolocation.getCurrentPosition((position) => {
        console.log(position.coords.latitude + ',' + position.coords.longitude);
        this.location = String(position.coords.latitude + ',' + position.coords.longitude);
      });
    }
    const dateObj = new Date();

    this.packetdate = (dateObj.getDate()) + '/' + (dateObj.getMonth() + 1) + '/' + (dateObj.getFullYear());
   }

  ngOnInit(): void {
  }


  addSample()
  {
    this.formData.location = this.location;
    this.formData.packs = this.packs;
    this.formData.packetdate = this.packetdate;
    this.formData.bloodgroup = this.bloodgroup;
    this.formData.address = this.address;
    this.formData.phoneNumber = this.phoneNumber;
    this.formData.phlevel = this.phlevel;
    this.formData.pressure = this.pressure;

    console.log(this.formData);
    this.loader = true;
    this.httpReq.postReq('http://localhost:8080/addSample/', this.formData).subscribe(
      response => {
        console.log(response);
        this.loader = false;
      },
      err => {
        this.loader = false;
       });
   }
}
