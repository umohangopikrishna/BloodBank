import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateDonerCompComponent } from './update-doner-comp.component';

describe('UpdateDonerCompComponent', () => {
  let component: UpdateDonerCompComponent;
  let fixture: ComponentFixture<UpdateDonerCompComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateDonerCompComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateDonerCompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
