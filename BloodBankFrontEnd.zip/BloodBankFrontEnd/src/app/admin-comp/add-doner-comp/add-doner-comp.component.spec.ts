import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddDonerCompComponent } from './add-doner-comp.component';

describe('AddDonerCompComponent', () => {
  let component: AddDonerCompComponent;
  let fixture: ComponentFixture<AddDonerCompComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddDonerCompComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddDonerCompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
