import { Component, OnInit } from '@angular/core';
import { MyServicesService } from 'src/app/HttpServices/my-services.service';

@Component({
  selector: 'app-add-doner-comp',
  templateUrl: './add-doner-comp.component.html',
  styleUrls: ['./add-doner-comp.component.css']
})
export class AddDonerCompComponent implements OnInit {

   weight: number;
   age: number;
  phoneNumber: string;
   address: string;
   pHLevel: string;
  pressure: string;
   bloodgroup: string;
  donarName: string;

  formData: any = {
    weight: 0,
    age: 0,
    phoneNumber: '',
    address: '',
    pHLevel: '',
    pressure: '',
    bloodgroup: '',
    donarName: ''
  };
  loader: boolean;
  constructor(private httpReq: MyServicesService) {
    this.bloodgroup = '';
    this.loader = false;
   }

  ngOnInit(): void {
  }
  addUser()
  {
    this.formData.weight = this.weight;
    this.formData.age = this.age;
    this.formData.phoneNumber = this.phoneNumber;
    this.formData.address = this.address;
    this.formData.pHLevel = this.pHLevel;
    this.formData.pressure = this.pressure;
    this.formData.bloodgroup = this.bloodgroup;
    this.formData.donarName = this.donarName;
    console.log(this.formData);
    this.loader = true;
    this.httpReq.postReq('http://localhost:8080/addDoner/', this.formData).subscribe(
      response => {
        console.log(response);
        this.loader = false;
      },
      err => {
        this.loader = false;
      });

  }
}
