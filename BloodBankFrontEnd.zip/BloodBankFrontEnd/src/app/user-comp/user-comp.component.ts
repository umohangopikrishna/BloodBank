import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-comp',
  templateUrl: './user-comp.component.html',
  styleUrls: ['./user-comp.component.css']
})
export class UserCompComponent implements OnInit {
  optionSelected: number;
  constructor(private router: Router) {
    this.optionSelected = 1;
    if (sessionStorage.getItem('checkSequencePath') !== 'true') {
      this.router.navigate([''], { replaceUrl: true });
    }
  }

  ngOnInit(): void {
  }

}
