import { Component, OnInit } from '@angular/core';
import { MyServicesService } from 'src/app/HttpServices/my-services.service';

@Component({
  selector: 'app-user-sample-comp',
  templateUrl: './user-sample-comp.component.html',
  styleUrls: ['./user-sample-comp.component.css']
})
export class UserSampleCompComponent implements OnInit {

  sampleDataList: any = [];
  samplesearchList: any = [];
  searchData: string;

  nearestBloodBankList: any = [];
  latitudemy: number;
  longitudemy: number;

  constructor(private httpReq: MyServicesService) { }

  ngOnInit(): void {
    this.searchData = '';
    this.getAllSamples();
  }
  refreshSamples() {
    this.getAllSamples();
  }
  getAllSamples() {
    this.httpReq.getReq('http://localhost:8080/getAllSamples/').subscribe(
      response => {
        this.sampleDataList = response;
        console.log(this.sampleDataList);
        this.searchByFields();
      });
  }

  searchByFields() {
    const data = this.searchData;

    this.samplesearchList = [];
    for (const sampleIndex in this.sampleDataList) {

      if (String(this.sampleDataList[sampleIndex].bloodgroup).includes(data)) {
        this.samplesearchList.push(this.sampleDataList[sampleIndex]);
        console.log('B+');

      }
      else if (String(this.sampleDataList[sampleIndex].pressure).includes(data)) {
        this.samplesearchList.push(this.sampleDataList[sampleIndex]);
      }
      else if (String(this.sampleDataList[sampleIndex].phoneNumber).includes(data)) {
        this.samplesearchList.push(this.sampleDataList[sampleIndex]);
      }
      else if (String(this.sampleDataList[sampleIndex].phlevel).includes(data)) {
        this.samplesearchList.push(this.sampleDataList[sampleIndex]);
      }
      else if (String(this.sampleDataList[sampleIndex].packs).includes(data)) {
        this.samplesearchList.push(this.sampleDataList[sampleIndex]);
      }
      else if (String(this.sampleDataList[sampleIndex].address).includes(data)) {
        this.samplesearchList.push(this.sampleDataList[sampleIndex]);
      }
      else if (String(this.sampleDataList[sampleIndex].id).includes(data)) {
        this.samplesearchList.push(this.sampleDataList[sampleIndex]);
      } else if (data === '') {
        this.samplesearchList.push(this.sampleDataList[sampleIndex]);
        console.log('Empty');
      }

    }
  }

  geoLocation()
  {
     this.latitudemy = 0;
     this.longitudemy = 0;
     if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (showPosition) => {
          this.latitudemy = showPosition.coords.longitude;
          this.longitudemy = showPosition.coords.latitude;
          console.log('hello');
          this.nearestBloodBank();
        });
    }
   }

  nearestBloodBank()
  {
    this.nearestBloodBankList = [];
    console.log(this.latitudemy + ' ' + this.longitudemy);
    // tslint:disable-next-line:forin
    for (const indexes in this.samplesearchList)
    {
      const longitudeBB = Number(this.samplesearchList[indexes].location.split(',')[0]);
      const latitudeBB = Number(this.samplesearchList[indexes].location.split(',')[1]);
      console.log(latitudeBB +  ' ' + longitudeBB);
      this.nearestBloodBankList.push(
        {
       sampleData: this.samplesearchList[indexes],
// tslint:disable-next-line:max-line-length
       distanceParam: (((this.latitudemy - latitudeBB) * (this.latitudemy - latitudeBB)) + ((this.longitudemy - longitudeBB) * (this.longitudemy - longitudeBB)))
        });
    }
    this.nearestBloodBankList.sort(
      (a, b) => {
        return (a.distanceParam - b.distanceParam);
      });
    console.log(this.nearestBloodBankList);

    this.samplesearchList = [];
    // tslint:disable-next-line:forin
    for (const indexs in this.nearestBloodBankList)
    {
      this.samplesearchList.push(this.nearestBloodBankList[indexs].sampleData);
     }

  }

}
