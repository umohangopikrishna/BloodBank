import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminCompComponent } from './admin-comp/admin-comp.component';
import { BloodBankHomeComponent } from './blood-bank-home/blood-bank-home.component';
import { ForgetPasswordCompComponent } from './forget-password-comp/forget-password-comp.component';
import { LoginCompComponent } from './login-comp/login-comp.component';
import { RegistrationCompComponent } from './registration-comp/registration-comp.component';
import { UserCompComponent } from './user-comp/user-comp.component';


const routes: Routes = [
      {
        path: 'login/:typeUser', component: LoginCompComponent,
      },
      {
        path: 'register/:typeUser', component: RegistrationCompComponent
  },
  {
    path: 'adminHome', component: AdminCompComponent
  },
  {
    path: 'userHome', component: UserCompComponent
  },
  {
    path: 'bloodBankHome', component: BloodBankHomeComponent
  },
  {
    path: '', component: BloodBankHomeComponent
  },
  { path: 'forgetpassword/:typeUser', component: ForgetPasswordCompComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
