import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MyServicesService } from '../HttpServices/my-services.service';

@Component({
  selector: 'app-registration-comp',
  templateUrl: './registration-comp.component.html',
  styleUrls: ['./registration-comp.component.css']
})
export class RegistrationCompComponent implements OnInit {


  firstName: string;
  lastName: string;
  password: string;
  confirmPassword: string;
  gmailId: string;
  phoneNumber: string;
  userId: string;


  formData: any = { firstName: '', lastName: '', password: '', gmailId: '', phoneNumber: '', typeUser: '', userID: '' };
  validationData: any = [false, false];

  typeUser: string;
  imgIcon: string;
  resultFlage: boolean;

  loader: boolean;
  constructor(private routeActive: ActivatedRoute, private httpObj: MyServicesService) { }

  ngOnInit(): void {
    this.loader = false;
    this.resultFlage = true;
    this.routeActive.params.subscribe(params => {
      console.log(params);
      this.typeUser = params.typeUser;
      if (params.typeUser === 'user') {
        // this.typeUser = 0;
        this.imgIcon = 'https://st2.depositphotos.com/7107694/10781/v/950/depositphotos_107818026-stock-illustration-patient-flat-vector-symbol.jpg';

      }
      else {
       // this.typeUser = 1;
        this.imgIcon = 'https://www.iconsdb.com/icons/preview/red/administrator-xxl.png';
      }
    });
  }
  UserRegistration(formData: any)
  {
    this.formData.firstName = this.firstName;
    this.formData.lastName = this.lastName;
    this.formData.password = this.password;
    this.formData.phoneNumber = this.phoneNumber;
    this.formData.gmailId = this.gmailId;
    this.formData.typeUser = this.typeUser;
    this.formData.userID = this.userId;
    this.loader = true;
    this.httpObj.postReq('http://localhost:8080/UserRegistration/', this.formData).subscribe(
      response => {
        console.log(response);
        this.validationData = response;
        this.loader = false;
        this.resultFlage = this.validationData[0] && this.validationData[1] && this.validationData[2];
      },
    err => {
      this.loader = false;
     });
   }

}
