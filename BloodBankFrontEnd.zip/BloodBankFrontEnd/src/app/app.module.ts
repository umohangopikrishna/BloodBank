import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginCompComponent } from './login-comp/login-comp.component';
import { RegistrationCompComponent } from './registration-comp/registration-comp.component';
import { ResultCompComponent } from './registration-comp/result-comp/result-comp.component';
import { AdminCompComponent } from './admin-comp/admin-comp.component';
import { AddDonerCompComponent } from './admin-comp/add-doner-comp/add-doner-comp.component';
import { UpdateDonerCompComponent } from './admin-comp/update-doner-comp/update-doner-comp.component';
import { BloodBankHomeComponent } from './blood-bank-home/blood-bank-home.component';
import { DonarBoxComponent } from './admin-comp/donar-box/donar-box.component';
import { SampleCompComponent } from './admin-comp/sample-comp/sample-comp.component';
import { SampleBoxComponent } from './admin-comp/sample-comp/sample-box/sample-box.component';
import { AddSampleComponent } from './admin-comp/sample-comp/add-sample/add-sample.component';
import { UpdateSampleComponent } from './admin-comp/sample-comp/update-sample/update-sample.component';
import { UserCompComponent } from './user-comp/user-comp.component';
import { UserDonarCompComponent } from './user-comp/user-donar-comp/user-donar-comp.component';
import { UserSampleCompComponent } from './user-comp/user-sample-comp/user-sample-comp.component';
import { ForgetPasswordCompComponent } from './forget-password-comp/forget-password-comp.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginCompComponent,
    RegistrationCompComponent,
    ResultCompComponent,
    AdminCompComponent,
    AddDonerCompComponent,
    UpdateDonerCompComponent,
    BloodBankHomeComponent,
    DonarBoxComponent,
    SampleCompComponent,
    SampleBoxComponent,
    AddSampleComponent,
    UpdateSampleComponent,
    UserCompComponent,
    UserDonarCompComponent,
    UserSampleCompComponent,
    ForgetPasswordCompComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
